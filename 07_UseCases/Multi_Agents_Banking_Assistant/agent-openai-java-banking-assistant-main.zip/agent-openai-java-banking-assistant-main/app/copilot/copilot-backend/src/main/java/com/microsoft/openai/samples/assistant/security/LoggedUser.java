package com.microsoft.openai.samples.assistant.security;

public record  LoggedUser(String username, String mail, String role, String displayName) {

}
