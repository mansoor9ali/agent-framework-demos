// Copyright (c) Microsoft. All rights reserved.
package com.microsoft.openai.samples.assistant.controller;

public record ChatAppRequestContext(ChatAppRequestOverrides overrides) {}
