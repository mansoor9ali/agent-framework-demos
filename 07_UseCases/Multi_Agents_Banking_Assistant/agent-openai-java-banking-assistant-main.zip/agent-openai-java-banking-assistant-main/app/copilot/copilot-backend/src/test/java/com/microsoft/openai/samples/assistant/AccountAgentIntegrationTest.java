package com.microsoft.openai.samples.assistant;

public class AccountAgentIntegrationTest {

    public static void main(String[] args) {

    }
}
