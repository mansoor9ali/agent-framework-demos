package com.microsoft.langchain4j.agent.mcp;

public record MCPServerMetadata(String serverName, String url, MCPProtocolType protocolType) {
}

