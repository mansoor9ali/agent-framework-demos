package com.microsoft.langchain4j.agent;

import java.util.List;

public record AgentMetadata(String description, List<String> intents) {
}

