package com.microsoft.langchain4j.agent.mcp;

public  enum MCPProtocolType {
    SSE,
    STDIO
}
