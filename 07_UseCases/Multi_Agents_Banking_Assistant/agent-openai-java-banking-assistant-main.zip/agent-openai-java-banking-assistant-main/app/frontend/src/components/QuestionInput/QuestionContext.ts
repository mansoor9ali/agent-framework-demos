import { AttachmentType } from "../AttachmentType";

export type QuestionContextType = {
    question: string;
    attachments?: string[];
   
};