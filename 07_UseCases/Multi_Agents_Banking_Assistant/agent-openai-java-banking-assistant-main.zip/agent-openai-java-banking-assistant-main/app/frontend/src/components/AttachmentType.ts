export type AttachmentType = {
    name: string;
    file: File; //Reference to the javascript File object.
};